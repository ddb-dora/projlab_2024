package Model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Room {

    private List<Room> neighbors = new ArrayList<Room>();
    private List<Character> characters = new ArrayList<Character>();
    private List<Item> items = new ArrayList<Item>();

    //A szoba max kapacitasa
    private int maxCapacity = 5;
    //A szoba jelenlegi kapacitasa
    private int capacity;
    //Ha a szoba el van gazosítva, akkor true, egyebkent false
    private boolean poisonous = false;
    //Ha a szoba el van atkozva, akkor true, egyebkent false
    private boolean cursed = false;

    //A szoba beengedi magaba a karaktert, ha van szabad hely
    public void Accept(Character ch){
        if(capacity < maxCapacity){
            this.characters.add(ch);
            this.capacity += 1;
        }
    }

    //A szoba eltavolitja magaból a karaktert
    public void Remove(Character ch){
        this.characters.remove(ch);
        capacity -= 1;
    }

    //Karakter hozzaadasa a szobahoz manualisan
    //A jatek indítasanallesz nagyobb szerepe
    public void AddCharacter(Character ch) {
        this.characters.add(ch);
        capacity += 1;
    }

    //Getter a maxCapacity attribútumhoz
    public int GetMaxCapacity(){
        return maxCapacity;
    }

    //Getter a capacity attribútumhoz
    public int GetCapacity(){
        return capacity;
    }

    //Getter a character listahoz
    public List<Character> GetCharacters(){
        return characters;
    }
    //Getter a szomszedaihoz
    public List<Room> GetNeighbors(){
        return neighbors;
    }
    //Getter az Itemekhez
    public List<Item> GetItems(){
        return items;
    }
    
    //Szomszed hozzaadasa a szobahoz
    //A jatek indítasanal lesz nagyobb szerepe
    public void SetNeighbor(Room r){
        neighbors.add(r);
    }

    //Igazzal ter vissza ha az adott szoba
    //rendelkezik ilyen szomszeddal
    public boolean HasNeigbor(Room r){
        return neighbors.contains(r);
    }

    //Eltavolítja a szomszedai közül a parametekent kapott szobat
    public void RemoveNeighbor(Room r){
        neighbors.remove(r);
    }

    //Random szamot general,
    //a veletlenszerűen törtenő esemenyeknel lesz szerepe
    private boolean getRandom(Random random){
        int i = random.nextInt(2) + 1; // Random int between 1 and 2
        if(i == 1){
            return true;
        }
        else{
            return false;
        }
    }

    //A szoba leptetese
    public void Step(int round){
        Random random = new Random();
        //Random merge, separate, cursed
        if(getRandom(random)){
            int randomroom_num = random.nextInt(neighbors.size());
            Room r = neighbors.get(randomroom_num);
            MergeRooms(r);
        }
        if(getRandom(random)){
            SeparateRoom();
        }

        if(getRandom(random)){
            SetCursed();
        }

        if(poisonous == true){
            //If the room is poisonous the all characters faint
            for(Character ch : characters){
                ch.Faint();
            }
        }
        //Each character takes its turn
        for(Character ch : characters){
            ch.Step();
        }
    }

    //Szoba kettevalasa
    public void SeparateRoom(){
        System.out.print("SeparateRoom()");

        //Letrejön az új szoba, ami szomszedos lesz ezzel
        Room r = new Room();

        //A letrejövő szoba rendelkezni fog az eredeti tulajdonsagaival
        if(poisonous)
            r.poisonous = true;

        if(cursed)
            r.cursed = true;
        r.maxCapacity = capacity;


        Random random = new Random();
        //Veletlenszerűen kap az új szoba szomszedokat
        for(Room r1 : neighbors){
            if(getRandom(random)){
                r.neighbors.add(r1);
                //Ha a masik szoba szomszedos ezzel
                if(r1.HasNeigbor(this)){
                    r1.RemoveNeighbor(this);
                    r1.neighbors.add(r);
                }
            }
        }
        //Eltavolítja a masik szobahoz sorolt szomszedokat
        if(!r.neighbors.isEmpty()){
            for(Room r1 : r.neighbors){
                neighbors.remove(r1);
            }
        }

        //Veletlenszerűen kap az új szoba targyakat
        for(Item i1 : items){
            if(getRandom(random)){
                r.items.add(i1);
                i1.SetRoom(r);
            }
        }
        //Eltavolítja a masik szobahoz sorolt targyakat
        if(!r.items.isEmpty()){
            for(Item i1 : r.items){
                items.remove(i1);
            }
        }
        //Megkapja a masik szobat mint szomszed
        r.neighbors.add(this);
        neighbors.add(r);
    }

    //Szobak egyesülese
    //Ezt a szobat egyesíti egy kapott masikkal
    public void MergeRooms(Room r){
        System.out.println("MergeRooms(room)\n" +
                        "    ");
        //Ha nem fernenek el a karakterek, akkor nem egyesül a ket szoba
        if(r.capacity + capacity > Math.max(r.maxCapacity, maxCapacity)){
            return;
        }
        //A nagyobb befogadókepesseggel fog rendelkezni
        maxCapacity = Math.max(r.maxCapacity, maxCapacity);

        //Iteralas a masik szoba szomszedain
        for(Room r1 : r.GetNeighbors()){
            //Ha a masik szobanak szomszedja(ketiranyú ajtó)
            //atallítja az asszociaciót
            if(r1.HasNeigbor(r)){
                r1.RemoveNeighbor(r);
                r1.SetNeighbor(this);
            }
            //Ha ennek a szobanak meg nem szomszedja
            if(!neighbors.contains(r1)){
                neighbors.add(r1);
            }
        }
        //Minden a masik szobaban talalható targy ebbe kerül
        for(Item i : r.GetItems()){
            i.SetRoom(this);
        }
        items.addAll(r.GetItems());

        //Minden a masik szobaban talalható character ebbe kerül
        for(Character c : r.characters){
            c.SetRoom(this);
        }
        characters.addAll(r.characters);
        capacity += r.capacity;

        //Ha mergező vagy atkozott volt a masik
        if(r.poisonous)
            poisonous = true;
        
        if(r.cursed)
            cursed = true;
        
    }

    //A szoba elgazosítasakor a poisonous attribútum true-ra allítasa
    public void GetPoisonous(){
        poisonous = true;
    }

    //A szoba elatkozott attribútumanak allítasa
    public void SetCursed(){
        if(cursed == true) cursed = false;
        else cursed = true;
    }

    //Egy targy karakternek való atadasanak kezdemenyezese,
    //a szoba hívja meg
    public void GiveItemTo(ItemVisitor v, Item i){
        //TestPrint
        System.out.print("GiveItemTo(ch) -> Room\n" + 
                           "         ");
        int it = items.indexOf(i);
        items.get(it).Accept(v,true);
        RemoveItemFromRoom(i);

    }

    //Targy eltavolítasa a szobaból,
    //a targy felvetele eseten
    public void RemoveItemFromRoom(Item i){
        items.remove(i);
        i.SetRoom(null);
    }

    //Targy hozzaadasa a szobahoz,
    //a targy letevese eseten
    public void AddItemToRoom(Item i){
        items.add(i);
        i.SetRoom(this);
    }

    //Tranzisztor lehelyezese a szobaban
    //Ha csatlakoztatott tranzisztort teszünk le akkor teleportalas is törtenik, 
    //különben csak le lesz teve (at lesz adva a szobanak)
    public void PlaceTransistor(Transistor t, Character ch){
        this.AddItemToRoom(t);
        ch.RemoveItemFromInventory(t);
        boolean succesful = false;
        if(t.GetConnected()){
            succesful = ch.Teleport();
            System.out.println(succesful);
        }
        if(succesful){
            t.SetActivation(false);
            t.SetConnection(false);
        }
        
    }

}
